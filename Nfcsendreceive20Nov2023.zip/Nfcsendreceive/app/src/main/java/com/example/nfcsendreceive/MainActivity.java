package com.example.nfcsendreceive;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private EditText editTextMessage;
    private TextView textReceivedMessage;
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextMessage = findViewById(R.id.editTextMessage);
        textReceivedMessage = findViewById(R.id.textReceivedMessage);
        textReceivedMessage.setText("No message received yet"); // Default message

        Button btnSend = findViewById(R.id.btnSend);
        Button btnRefresh = findViewById(R.id.btnRefresh); // Add refresh button

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter != null) {
            Intent intent = new Intent(this, getClass());
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            pendingIntent = PendingIntent.getActivity(
                    this, 0, intent, PendingIntent.FLAG_MUTABLE);
        }

        btnSend.setOnClickListener(v -> {
            String messageToSend = editTextMessage.getText().toString();
            if (messageToSend.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a message", Toast.LENGTH_SHORT).show();
            } else {
                if (nfcAdapter == null) {
                    Toast.makeText(MainActivity.this, "NFC is not available on this device", Toast.LENGTH_SHORT).show();
                } else if (!nfcAdapter.isEnabled()) {
                    Toast.makeText(MainActivity.this, "NFC is disabled on this device", Toast.LENGTH_SHORT).show();
                    showNfcSettingsDialog();
                } else {
                    sendNfcMessage(messageToSend);
                    Toast.makeText(MainActivity.this, "NFC Enabled", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnRefresh.setOnClickListener(v -> {
            textReceivedMessage.setText("No message received yet"); // Reset received message
        });
    }

    private void sendNfcMessage(String message) {
        NdefMessage ndefMessage = new NdefMessage(
                new NdefRecord[]{NdefRecord.createMime("text/plain", message.getBytes())});

        Intent intent = new Intent(NfcAdapter.ACTION_NDEF_DISCOVERED);
        intent.setType("text/plain");
        intent.putExtra(NfcAdapter.EXTRA_NDEF_MESSAGES, new NdefMessage[]{ndefMessage});
        startActivity(intent);
    }

    private void showNfcSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("NFC is disabled");
        builder.setMessage("Please enable NFC in settings to use this feature");
        builder.setPositiveButton("Settings", (dialog, which) -> {
            Intent nfcSettingsIntent = new Intent(Settings.ACTION_NFC_SETTINGS);
            startActivity(nfcSettingsIntent);
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null) {
            IntentFilter[] intentFiltersArray = new IntentFilter[]{};
            String[][] techListsArray = new String[][]{};
            nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFiltersArray, techListsArray);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Tag tagFromIntent = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tagFromIntent != null) {
            handleTag(tagFromIntent);
            extractReceivedMessage(tagFromIntent);
        }
    }

    private void handleTag(Tag tag) {
        String[] techList = tag.getTechList();

        boolean isNdefSupported = Arrays.asList(techList).contains(Ndef.class.getName());
        boolean isNdefFormatableSupported = Arrays.asList(techList).contains(NdefFormatable.class.getName());

        if (isNdefSupported) {
            Ndef ndef = Ndef.get(tag);
            if (ndef != null) {
                handleNdefTag(ndef);
                return;
            }
        }

        if (isNdefFormatableSupported) {
            NdefFormatable ndefFormatable = NdefFormatable.get(tag);
            if (ndefFormatable != null) {
                handleNdefFormatableTag(ndefFormatable);
                return;
            }
        }

        handleUnsupportedTag();
    }

    private void handleNdefTag(Ndef ndef) {
        try {
            ndef.connect();
            NdefMessage receivedMessage = ndef.getNdefMessage();
            if (receivedMessage != null) {
                String receivedMsgString = new String(receivedMessage.getRecords()[0].getPayload());
                textReceivedMessage.setText(receivedMsgString);
            } else {
                textReceivedMessage.setText("Connected but, No message received yet"); // No message found
            }
            ndef.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error reading NFC", Toast.LENGTH_SHORT).show();
            textReceivedMessage.setText("Connected but, Error reading NFC"); // Error in connection
        }
    }

    private void handleNdefFormatableTag(NdefFormatable ndefFormatable) {
        try {
            ndefFormatable.connect();
            NdefMessage newMessage = createNdefMessage();
            ndefFormatable.format(newMessage);
            Toast.makeText(MainActivity.this, "Tag formatted and written with a new message", Toast.LENGTH_SHORT).show();
            ndefFormatable.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error formatting the tag", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleUnsupportedTag() {
        Toast.makeText(MainActivity.this, "Tag does not support NDEF or NDEF Formatable", Toast.LENGTH_SHORT).show();
    }

    private void extractReceivedMessage(Tag tag) {
        Ndef ndef = Ndef.get(tag);
        if (ndef != null) {
            try {
                ndef.connect();
                NdefMessage receivedMessage = ndef.getNdefMessage();
                if (receivedMessage != null) {
                    String receivedMsgString = new String(receivedMessage.getRecords()[0].getPayload());
                    textReceivedMessage.setText(receivedMsgString);
                } else {
                    textReceivedMessage.setText("Connected but, No message received yet"); // No message found
                }
                ndef.close();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Error reading NFC", Toast.LENGTH_SHORT).show();
                textReceivedMessage.setText("Connected but, Error reading NFC"); // Error in connection
            }
        } else {
            Toast.makeText(MainActivity.this, "Tag does not support NDEF", Toast.LENGTH_SHORT).show();
            textReceivedMessage.setText("Tag does not support NDEF"); // Tag doesn't support NDEF
        }
    }

    private NdefMessage createNdefMessage() {
        return new NdefMessage(
                new NdefRecord[]{NdefRecord.createMime("text/plain", "Your new message".getBytes())});
    }
}
